#ifndef ServicioProductos_hpp
#define ServicioProductos_hpp

#include <string>
#include <vector>
#include "Proforma.hpp"

// Resultado listo para que la capa de red arme la respuesta HTTP
struct RespuestaServicio {
   int codigo;                  // 200, 400, 404, 422...
   std::string frase;           // "OK", "Bad Request"...
   std::string tipoContenido;   // "text/html; charset=utf-8"
   std::string cuerpo;          // HTML
};

class ServicioProductos {
   public:
      virtual ~ServicioProductos() {}

      virtual RespuestaServicio ListarCategorias() const = 0;
      virtual RespuestaServicio ListarProductos( const std::string & categoria ) const = 0;
      virtual RespuestaServicio GenerarProforma( const std::vector<SolicitudItem> & items ) const = 0;
      virtual RespuestaServicio ListarServidores() const { return Error( 404, "No soportado" ); }
      virtual RespuestaServicio ListarRutas() const { return Error( 404, "No soportado" ); }
      virtual RespuestaServicio RegistrarServidor( const std::string &, const std::string &, int,const std::vector<std::string> & ) const {
         return Error( 404, "No soportado" );
      }
      // Un servidor de productos avisa que se apaga: su ruta se inhabilita
      virtual RespuestaServicio DesregistrarServidor( const std::string &, int ) const { return Error( 404, "No soportado" ); }
      virtual RespuestaServicio ListarBitacora( const std::string & ) const { return Error( 404, "No soportado" ); }

      // Para rutas desconocidas, metodos no soportados, parametros mal formados, etc.
      RespuestaServicio Error( int codigo, const std::string & detalle ) const;

   protected:
      static RespuestaServicio Construir( int codigo, const std::string & cuerpo );
      static std::string Frase( int codigo );
};

#endif